public abstract class SelfServiceKiosk implements Trackable {
    protected String location;

    public String getLocation() {
        return location;
    }
}
