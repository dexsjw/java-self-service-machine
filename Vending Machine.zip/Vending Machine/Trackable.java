public interface Trackable {
    void track();
}
