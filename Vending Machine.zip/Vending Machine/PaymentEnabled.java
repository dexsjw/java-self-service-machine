public interface PaymentEnabled {
    void pay(double amout);
}
